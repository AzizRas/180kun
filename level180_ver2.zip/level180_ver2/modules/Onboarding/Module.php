<?php
declare(strict_types=1);

namespace Modules\Onboarding;

use App\BaseModule;
use App\Container;
use App\Kernel;
use Modules\Onboarding\Domain\Profiles;

final class Module extends BaseModule
{
    public function register(Container $container, Kernel $kernel): void
    {
        $container->singleton(Profiles::class, static fn() => new Profiles($kernel), 'onboarding');
    }

    public function boot(Kernel $kernel): void
    {
        // Планировщику нужно знать, есть ли ограничения по нагрузке.
        // Он не лезет в таблицу скрининга — спрашивает событием,
        // а мы отвечаем, потому что этой таблицей владеем мы.
        $kernel->events->on('planning.load_limits', static function (array $p) use ($kernel): array {
            $row = $kernel->db()->first(
                'SELECT needs_doctor FROM onboarding_screening WHERE user_id = ?',
                [(int) ($p['user_id'] ?? 0)]
            );
            if ($row !== null && (int) $row['needs_doctor'] === 1) {
                $p['limited'] = true;
            }
            return $p;
        }, 'onboarding');

        // Модуль сквадов включили, когда человек уже прошёл онбординг, —
        // он спрашивает профиль событием. Отдаём только то, что нужно подбору.
        $kernel->events->on('squad.profile_lookup', static function (array $p) use ($kernel): array {
            $userId   = (int) ($p['user_id'] ?? 0);
            $profiles = $kernel->container->get(Profiles::class);
            $row      = $userId > 0 ? $profiles->find($userId) : null;
            if ($row === null) {
                return $p;
            }
            $p['profile']  = $profiles->publicProfile($row) + ['experience' => (string) $row['experience']];
            $p['baseline'] = $profiles->baseline($userId);
            return $p;
        }, 'onboarding');

        // Тренеру — профиль и baseline. Свободный текст (ограничения)
        // не отдаём: в модель уходит только обезличенное (Р-19).
        $kernel->events->on('coach.context', static function (array $p) use ($kernel): array {
            $profiles = $kernel->container->get(Profiles::class);
            $row      = $profiles->find((int) ($p['user_id'] ?? 0));
            if ($row !== null) {
                $p['profile']  = $profiles->publicProfile($row) + ['experience' => (string) $row['experience']];
                $p['baseline'] = $profiles->baseline((int) $p['user_id']);
            }
            return $p;
        }, 'onboarding');

        // Права на данные (Р-19): выгрузка и удаление — только своих таблиц.
        \App\UserData::register($kernel, 'onboarding', 'onboarding_', [
            'onboarding_profiles'  => [],
            'onboarding_screening' => [],
            'onboarding_baseline'  => [],
        ]);
    }
}
